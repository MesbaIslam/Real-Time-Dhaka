package com.example.cse_499;

public class Utils {

    public static int UPLOAD_IMAGE_RESPONSE = 2938;
}
