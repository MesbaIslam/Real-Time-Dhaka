package com.example.cse_499;


public class DataModel {
    Double latitude = 0.0;
    Double longitude = 0.0;
    String imageLink = "";
    Long time = System.currentTimeMillis();
    String category="";
}
